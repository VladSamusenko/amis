from parking.models import ParkingPlace
from django import forms
from django.forms.widgets import PasswordInput, NumberInput, TextInput
import datetime

class ParkingPlaceForm(forms.ModelForm):
    # car_parked
    name = forms.CharField(max_length=50)
    adress = forms.CharField(max_length=50)
    description = forms.CharField(max_length=50, required=False)
    busy_from = forms.DateTimeField(required=False, initial=datetime.datetime.now().strftime("%Y-%m-%d %H:%M"), widget=TextInput(attrs={'class':'validate', 'pattern':"(20[0-8][0-9]|209[0-9])-(0[1-9]|1[0-2])-([1-9]|[12][0-9]|30)\s([0-9]|1[0-9]|2[0-4]):([0-9]|[1-4][0-9]|5[0-9])", 'title': "YYYY-MM-DD HH:MM valid ranges: 2000-2099, 01-12, 1-30, 1-24, 0-59"}))
    busy_to = forms.DateTimeField(required=False, initial=datetime.datetime.now().strftime("%Y-%m-%d %H:%M"), widget=TextInput(attrs={'class':'validate', 'pattern':"(20[0-8][0-9]|209[0-9])-(0[1-9]|1[0-2])-([1-9]|[12][0-9]|30)\s([0-9]|1[0-9]|2[0-4]):([0-9]|[1-4][0-9]|5[0-9])", 'title': "YYYY-MM-DD HH:MM valid ranges: 2000-2099, 01-12, 1-30, 1-24, 0-59"}))

    # busy_from
    # busy_to
    price_per_hour = forms.IntegerField(widget=NumberInput(attrs={'class':'validate', 'min':"1", 'max': "1000"}))
    
    class Meta:
        model = ParkingPlace
        # exclude = ('busy_from', 'busy_to')
        fields = '__all__'
