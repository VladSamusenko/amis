from django.conf.urls import url

from .views import *

urlpatterns = [

    url(r'^$', Admin.as_view(), name='admin_app_main'),

    url(r'^delete/(?P<pk>\d+)/$', Delete.as_view(), name='admin_app_delete'),

    url(r'^edit/(?P<pk>\d+)/$', Edit.as_view(), name='admin_app_edit'),

]
