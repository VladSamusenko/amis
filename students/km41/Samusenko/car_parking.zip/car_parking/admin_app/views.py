from django.shortcuts import render
from parking.models import ParkingPlace
from django.shortcuts import render, redirect
from django.core.urlresolvers import reverse
from django.views import View
from .forms import ParkingPlaceForm
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.db import connection
from django.db import transaction


@method_decorator(login_required, name='dispatch')
class Admin(View):
    template_name = 'admin_app/main.html'

    def get(self, request):
        form = ParkingPlaceForm()
        places = ParkingPlace.objects.all()
        return render(request, self.template_name, {'form': form, 'places': places})

    def post(self, request):
        form = ParkingPlaceForm(request.POST, request.FILES)
        if form.is_valid():

            car_parked = request.POST.get('car_parked')
            if car_parked:
                car_parked = int(request.POST.get('car_parked'))
            new_name = request.POST.get('name')
            adress = request.POST.get('adress')
            description = request.POST.get('description') or ''
            busy_from = request.POST.get('busy_from') or ''
            busy_to = request.POST.get('busy_to') or ''
            price_per_hour = int(request.POST.get('price_per_hour'))
            with transaction.atomic():
                cursor = connection.cursor()
                cursor.execute('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE')

                cursor.callproc('parking_place.place_create', [
                    car_parked,
                    new_name,
                    adress,
                    description,
                    busy_from,
                    busy_to,
                    price_per_hour])

            return redirect(reverse('admin_app:admin_app_main'))


        # if form.is_valid():
        #     form.save()
        #     return redirect(reverse('admin_app:admin_app_main'))
        return render(request, self.template_name, {'form':form})


@method_decorator(login_required, name='dispatch')
class Delete(View):

    def post(self, request, pk):
        # ParkingPlace.objects.get(pk=pk).delete()
        with transaction.atomic():
            cursor = connection.cursor()
            cursor.execute('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE')
            cursor.execute('DELETE PARKING_PARKINGPLACE WHERE ID={to_delete}'.format(
                to_delete=pk
                )
            )
        return redirect(reverse('admin_app:admin_app_main'))


@method_decorator(login_required, name='dispatch')
class Edit(View):
    template_name = 'admin_app/edit.html'

    def get(self, request, pk):
        place = ParkingPlace.objects.get(pk=pk)
        form = ParkingPlaceForm(instance=place)
        return render(request, self.template_name, {'form': form, 'place': place})

    def post(self, request, pk):
        place = ParkingPlace.objects.get(pk=pk)
        form = ParkingPlaceForm(request.POST, request.FILES, instance=place)

        if form.is_valid():
            car_parked = request.POST.get('car_parked')
            if car_parked:
                car_parked = int(request.POST.get('car_parked'))
            new_name = request.POST.get('name')
            adress = request.POST.get('adress')
            description = request.POST.get('description') or ''
            busy_from = request.POST.get('busy_from') or ''
            busy_to = request.POST.get('busy_to') or ''
            price_per_hour = int(request.POST.get('price_per_hour'))

            with transaction.atomic():
                cursor = connection.cursor()
                cursor.execute('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE')

                cursor.callproc('parking_place.place_update', [
                    car_parked,
                    new_name,
                    adress,
                    description,
                    busy_from,
                    busy_to,
                    price_per_hour,
                    pk])
                print(pk)
            return redirect(reverse('admin_app:admin_app_main'))

        # if form.is_valid():
        #     form.save()
        #     return redirect(reverse('admin_app:admin_app_main'))

        return render(request, self.template_name, {'form':form})
