from django.contrib.auth.decorators import login_required
from django.http import HttpResponseRedirect
from django.shortcuts import render, redirect
import datetime
from django.urls import reverse
from django.utils.decorators import method_decorator
from django.views import View
from django.utils import timezone
from django.db import connection
from django.db import transaction

from .models import Car, ParkingPlace, Order

@method_decorator(login_required, name='dispatch')
class ParkingDetails(View):

    def get(self, request, pk):
        parking_place = ParkingPlace.objects.get(pk=pk)
        now = timezone.now()

        orders_for_parking_place = Order.objects.filter(parking_place_id=parking_place.id)
        for order in orders_for_parking_place:
            if order.is_confirmed and order.parking_to > now:
                parking_place.car_parked = order.car_parked
                parking_place.busy_from = now
                parking_place.busy_to = order.parking_to
                parking_place.save()

        with transaction.atomic():
            with connection.cursor() as cursor:
                cursor.execute('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE')
                if parking_place.busy_to:
                    if now >= parking_place.busy_to:
                        parking_place.car_parked = None
                        parking_place.busy_from = None
                        parking_place.busy_to = None
                        parking_place.save()



        cars = Car.objects.all()
        return render(request, 'parking-details.html',
                      {'parking_place': parking_place, 'cars': cars,
                      'orders_for_parking_place': orders_for_parking_place})

    def post(self, request, pk):

        parking_place = ParkingPlace.objects.get(pk=pk)
        cars = Car.objects.all()
        post_data = request.POST.getlist('car')
        car_id, hours = int(post_data[0]), int(post_data[1])
        now = datetime.datetime.now()
        car = Car.objects.get(id=car_id)

        busy_to = now + datetime.timedelta(hours=hours)
        order_cost = parking_place.price_per_hour * hours
        is_confirmed = 0
        get_id = ''
        user_id=request.user.id

        with transaction.atomic():
            with connection.cursor() as cursor:
                cursor.execute('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE')
                
                # car.owner.add(request.user)
                if not Car.objects.filter(owner=request.user, id=car_id):
                    cursor.callproc('PACKAGE_CAR.CREATE_PROCEDURE', [car_id, user_id])

                order_id = int(cursor.callproc('PACKAGE_ORDER.CREATE_PROCEDURE', [
                    request.user.id,
                    parking_place.id,
                    now,
                    busy_to,
                    car.id,
                    order_cost,
                    is_confirmed,
                    get_id])[-1])
        # order = Order.objects.create(
        #     user_id=request.user.id,
        #     parking_place_id=parking_place.id,
        #     parking_from=now,
        #     parking_to=busy_to,
        #     car_parked=car,
        #     cost=order_cost)

        return redirect(reverse('parking:order_details', args=(order_id,)))


@method_decorator(login_required, name='dispatch')
class OrderDetails(View):

    def get(self, request, pk):

        order = Order.objects.get(pk=pk)
        cursor = connection.cursor()
        cursor.execute('SELECT "CAR_PARKED",\
            "PARKING_FROM", \
            "PARKING_TO", \
            "COST", \
            "ORDER_TIME", \
            "IS_CONFIRMED", \
            "USERNAME", \
            "PARKINGPLACE_ID", \
            "PARKINGPLACE_NAME", \
            "ORDER_ID" \
            FROM "OrderDetailsPage" \
            WHERE "ORDER_ID" = {order_id}'.format(order_id=pk))

        CAR_PARKED, PARKING_FROM, PARKING_TO, COST, ORDER_TIME, IS_CONFIRMED, USERNAME, PARKINGPLACE_ID, PARKINGPLACE_NAME, ORDER_ID = cursor.fetchone()
        
        context = {
        "CAR_PARKED": CAR_PARKED,
        "PARKING_FROM": PARKING_FROM,
        "PARKING_TO": PARKING_TO,
        "COST": COST,
        "ORDER_TIME": ORDER_TIME,
        "IS_CONFIRMED": IS_CONFIRMED,
        "USERNAME": USERNAME,
        "PARKINGPLACE_ID": PARKINGPLACE_ID,
        "PARKINGPLACE_NAME": PARKINGPLACE_NAME
        }
        return render(request, 'order-details.html', context)


@method_decorator(login_required, name='dispatch')
class Orders(View):

    def get(self, request, pk):
        orders = Order.objects.filter(user_id=pk)

        return render(request, 'orders.html', {'orders': orders})
