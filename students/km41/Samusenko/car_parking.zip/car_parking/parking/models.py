from django.db import models


class Car(models.Model):
    owner = models.ManyToManyField('auth.User', blank=True)
    car_picture = models.ImageField(upload_to='cars/', blank=True,
                                    default='cars/no_car.jpg')
    model = models.CharField(max_length=50, default='No model')

    def __str__(self):
        return self.model


class ParkingPlace(models.Model):
    car_parked = models.ForeignKey(Car, blank=True, null=True, on_delete=models.SET_NULL)
    name = models.CharField(max_length=155)
    adress = models.CharField(max_length=155, unique=True)
    description = models.CharField(max_length=255, blank=True, null=True)
    busy_from = models.DateTimeField(blank=True, null=True)
    busy_to = models.DateTimeField(blank=True, null=True)
    price_per_hour = models.PositiveIntegerField(
        null=True, default=0)

    def __str__(self):
        return self.name


class Order(models.Model):
    user = models.ForeignKey('auth.User', on_delete=models.SET_NULL, null=True)
    parking_place = models.ForeignKey('ParkingPlace')
    car_parked = models.ForeignKey(Car, blank=True, null=True, on_delete=models.SET_NULL)
    parking_from = models.DateTimeField(blank=True, null=True)
    parking_to = models.DateTimeField(blank=True, null=True)
    cost = models.PositiveIntegerField(null=True, blank=True, default=0)
    is_confirmed = models.BooleanField(default=False)
    order_time = models.DateTimeField('Created', auto_now_add=True, null=True)

    def __str__(self):
        return 'Parking order of {user} from {time_from} to {time_to} on {parking_place} - [{order_time}]'.format(
            user=self.user.username,
            time_from=self.parking_from,
            time_to=self.parking_to,
            parking_place=self.parking_place,
            order_time=self.order_time)
