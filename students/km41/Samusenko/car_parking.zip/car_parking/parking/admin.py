from django.contrib import admin

from .models import Car, ParkingPlace, Order


admin.site.register(Car)
admin.site.register(ParkingPlace)
admin.site.register(Order)
