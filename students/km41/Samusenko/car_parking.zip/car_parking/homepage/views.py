from django.views import View
from django.contrib.auth import login, authenticate
from django.shortcuts import render, redirect
from django.utils import timezone

from parking.models import Car, ParkingPlace, Order
from .forms import SignUpForm

from django.db import connection
from django.db import transaction


class HomePage(View):

    def get(self, request, *args, **kwargs):
        # parking_places = ParkingPlace.objects.all()[:10]
        parking_places = ParkingPlace.objects.raw(
            'SELECT * FROM PARKING_PARKINGPLACE WHERE ROWNUM <= 10')
        now = timezone.now()


        with transaction.atomic():
            with connection.cursor() as cursor:
                cursor.execute('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE')

                for parking_place in parking_places:
                    orders_for_parking_place = Order.objects.filter(parking_place_id=parking_place.id)
                    for order in orders_for_parking_place:
                        if order.is_confirmed and order.parking_to > now:
                            parking_place.car_parked = order.car_parked
                            parking_place.busy_from = now
                            parking_place.busy_to = order.parking_to
                            parking_place.save()

                    if parking_place.busy_to:
                        if now >= parking_place.busy_to:
                            parking_place.car_parked = None
                            parking_place.busy_from = None
                            parking_place.busy_to = None
                            parking_place.save()

        template_name = 'home.html'

        return render(request, template_name, {'parking_places': parking_places})


def signup(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            raw_password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=raw_password)
            login(request, user)
            return redirect('/')
    else:
        form = SignUpForm()
    return render(request, 'registration/signup.html', {'form': form})